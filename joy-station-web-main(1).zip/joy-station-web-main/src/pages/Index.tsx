import { useGameState } from '@/hooks/useGameState';
import { BattleScreen } from '@/components/game/BattleScreen';
import { MenuScreen } from '@/components/game/MenuScreen';
import { GameOverScreen } from '@/components/game/GameOverScreen';

const Index = () => {
  const { state, actions } = useGameState();

  const renderScreen = () => {
    switch (state.gamePhase) {
      case 'menu':
        return <MenuScreen onStartBattle={actions.startBattle} />;
      case 'battle':
        return (
          <BattleScreen
            gameState={state}
            onSelectAction={actions.selectAction}
            onSelectAttack={actions.selectAttack}
            onSwitchMonster={actions.switchMonster}
            onEndTurn={actions.endTurn}
          />
        );
      case 'victory':
        return <GameOverScreen isVictory={true} onResetGame={actions.resetGame} />;
      case 'defeat':
        return <GameOverScreen isVictory={false} onResetGame={actions.resetGame} />;
      default:
        return <MenuScreen onStartBattle={actions.startBattle} />;
    }
  };

  return renderScreen();
};

export default Index;
