import { useEffect, useRef } from 'react';
import { audioManager } from '@/utils/audioManager';

export function useAudio() {
  const isInitialized = useRef(false);

  useEffect(() => {
    if (!isInitialized.current) {
      audioManager.loadGameAudio();
      isInitialized.current = true;
    }
  }, []);

  const playSound = (soundName: string) => {
    audioManager.play(soundName);
  };

  const setVolume = (volume: number) => {
    audioManager.setVolume(volume);
  };

  const mute = (muted: boolean = true) => {
    audioManager.mute(muted);
  };

  return {
    playSound,
    setVolume,
    mute,
  };
}