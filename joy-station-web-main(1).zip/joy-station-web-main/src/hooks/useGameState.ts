import { useReducer, useCallback } from 'react';
import { GameState, GameAction, Monster } from '../types/game';
import { MONSTER_DATA, getRandomAbilities, getRandomMonsterName, calculateDamage, ABILITIES_DATA } from '../data/gameData';

// Initial player monster names from original game
const PLAYER_MONSTER_NAMES = ["Sparchu", "Cleaf", "Jacana", "Pouch", "Larvea"];

function createMonster(name: string): Monster {
  const data = MONSTER_DATA[name];
  return {
    name,
    element: data.element,
    health: data.health,
    maxHealth: data.health,
    abilities: getRandomAbilities(4),
  };
}

const initialState: GameState = {
  playerMonsters: PLAYER_MONSTER_NAMES.map(createMonster),
  currentMonster: createMonster(PLAYER_MONSTER_NAMES[0]),
  opponent: createMonster(getRandomMonsterName()),
  isPlayerTurn: true,
  gamePhase: 'menu',
  animating: false,
};

function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case 'START_BATTLE':
      return {
        ...state,
        gamePhase: 'battle',
        isPlayerTurn: true,
      };

    case 'SELECT_ACTION':
      if (action.action === 'heal') {
        const newHealth = Math.min(state.currentMonster.maxHealth, state.currentMonster.health + 50);
        return {
          ...state,
          currentMonster: { ...state.currentMonster, health: newHealth },
          isPlayerTurn: false,
          animating: true,
        };
      }
      if (action.action === 'escape') {
        return { ...state, gamePhase: 'menu' };
      }
      return { ...state, selectedAction: action.action };

    case 'SELECT_ATTACK':
      if (!state.selectedAction || state.selectedAction !== 'attack') return state;
      
      const ability = ABILITIES_DATA[action.attack];
      const damage = calculateDamage(ability.element, state.opponent.element, ability.damage);
      const newOpponentHealth = Math.max(0, state.opponent.health - damage);
      
      return {
        ...state,
        opponent: { ...state.opponent, health: newOpponentHealth },
        selectedAction: undefined,
        selectedAttack: action.attack,
        isPlayerTurn: false,
        animating: true,
        gamePhase: newOpponentHealth <= 0 ? 'victory' : state.gamePhase,
      };

    case 'SWITCH_MONSTER':
      const updatedPlayerMonsters = state.playerMonsters.map(monster =>
        monster.name === state.currentMonster.name ? state.currentMonster : monster
      );
      
      return {
        ...state,
        playerMonsters: updatedPlayerMonsters,
        currentMonster: action.monster,
        selectedAction: undefined,
        isPlayerTurn: false,
        animating: true,
      };

    case 'APPLY_DAMAGE':
      if (action.target === 'player') {
        const newHealth = Math.max(0, state.currentMonster.health - action.damage);
        const updatedCurrentMonster = { ...state.currentMonster, health: newHealth };
        const updatedPlayerMonsters = state.playerMonsters.map(monster =>
          monster.name === state.currentMonster.name ? updatedCurrentMonster : monster
        );
        
        return {
          ...state,
          currentMonster: updatedCurrentMonster,
          playerMonsters: updatedPlayerMonsters,
          gamePhase: newHealth <= 0 ? 'defeat' : state.gamePhase,
        };
      }
      return state;

    case 'END_TURN':
      return {
        ...state,
        isPlayerTurn: !state.isPlayerTurn,
        animating: false,
        selectedAttack: undefined,
      };

    case 'RESET_GAME':
      return {
        ...initialState,
        playerMonsters: PLAYER_MONSTER_NAMES.map(createMonster),
        currentMonster: createMonster(PLAYER_MONSTER_NAMES[0]),
        opponent: createMonster(getRandomMonsterName()),
      };

    default:
      return state;
  }
}

export function useGameState() {
  const [state, dispatch] = useReducer(gameReducer, initialState);

  const selectAction = useCallback((action: 'attack' | 'heal' | 'switch' | 'escape') => {
    dispatch({ type: 'SELECT_ACTION', action });
  }, []);

  const selectAttack = useCallback((attack: string) => {
    dispatch({ type: 'SELECT_ATTACK', attack });
  }, []);

  const switchMonster = useCallback((monster: Monster) => {
    dispatch({ type: 'SWITCH_MONSTER', monster });
  }, []);

  const applyDamage = useCallback((target: 'player' | 'opponent', damage: number) => {
    dispatch({ type: 'APPLY_DAMAGE', target, damage });
  }, []);

  const endTurn = useCallback(() => {
    dispatch({ type: 'END_TURN' });
  }, []);

  const startBattle = useCallback(() => {
    dispatch({ type: 'START_BATTLE' });
  }, []);

  const resetGame = useCallback(() => {
    dispatch({ type: 'RESET_GAME' });
  }, []);

  return {
    state,
    actions: {
      selectAction,
      selectAttack,
      switchMonster,
      applyDamage,
      endTurn,
      startBattle,
      resetGame,
    },
  };
}