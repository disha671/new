// Audio Manager for Monster Battle Game
// Handles loading and playing sound effects

export class AudioManager {
  private static instance: AudioManager;
  private audioCache: Map<string, HTMLAudioElement> = new Map();
  private isMuted: boolean = false;
  private volume: number = 0.7;

  private constructor() {}

  static getInstance(): AudioManager {
    if (!AudioManager.instance) {
      AudioManager.instance = new AudioManager();
    }
    return AudioManager.instance;
  }

  async loadAudio(name: string, path: string): Promise<void> {
    if (this.audioCache.has(name)) return;

    try {
      const audio = new Audio(path);
      audio.volume = this.volume;
      audio.preload = 'auto';
      
      // Wait for audio to be loaded
      await new Promise((resolve, reject) => {
        audio.addEventListener('canplaythrough', resolve, { once: true });
        audio.addEventListener('error', reject, { once: true });
        audio.load();
      });

      this.audioCache.set(name, audio);
    } catch (error) {
      console.warn(`Failed to load audio: ${name}`, error);
    }
  }

  play(name: string): void {
    if (this.isMuted) return;

    const audio = this.audioCache.get(name);
    if (audio) {
      // Reset and play
      audio.currentTime = 0;
      audio.volume = this.volume;
      audio.play().catch(err => console.warn(`Failed to play audio: ${name}`, err));
    }
  }

  setVolume(volume: number): void {
    this.volume = Math.max(0, Math.min(1, volume));
    this.audioCache.forEach(audio => {
      audio.volume = this.volume;
    });
  }

  mute(muted: boolean = true): void {
    this.isMuted = muted;
  }

  // Load common game audio files
  async loadGameAudio(): Promise<void> {
    const audioFiles = [
      { name: 'attack', path: '/assets/audio/scratch.wav' },
      { name: 'fire', path: '/assets/audio/fire.wav' },
      { name: 'water', path: '/assets/audio/splash.wav' },
      { name: 'plant', path: '/assets/audio/green.wav' },
      { name: 'explosion', path: '/assets/audio/explosion.wav' },
      { name: 'ice', path: '/assets/audio/ice.wav' },
      { name: 'heal', path: '/assets/audio/green.wav' },
      { name: 'music', path: '/assets/audio/music.wav' },
    ];

    await Promise.allSettled(
      audioFiles.map(({ name, path }) => this.loadAudio(name, path))
    );
  }
}

// Create singleton instance
export const audioManager = AudioManager.getInstance();