import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AudioControls } from '@/components/ui/audio-controls';

interface MenuScreenProps {
  onStartBattle: () => void;
}

export function MenuScreen({ onStartBattle }: MenuScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted to-accent/20 flex items-center justify-center p-4">
      {/* Audio Controls - Fixed in top right */}
      <div className="fixed top-4 right-4 z-10">
        <AudioControls />
      </div>

      <Card className="max-w-2xl w-full p-8 bg-card/80 backdrop-blur-sm border-2 shadow-2xl animate-battle-enter">
        <div className="text-center space-y-8">
          <div className="space-y-4">
            <h1 className="text-6xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent animate-pulse-glow">
              Monster Battle
            </h1>
            <p className="text-xl text-muted-foreground">
              Enter the arena and battle with your monsters!
            </p>
          </div>

          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
              <div className="p-4 bg-fire/10 rounded-lg border border-fire/30">
                <div className="text-2xl mb-2">🔥</div>
                <h3 className="font-semibold text-fire">Fire Type</h3>
                <p className="text-sm text-muted-foreground">Strong vs Plant</p>
              </div>
              <div className="p-4 bg-water/10 rounded-lg border border-water/30">
                <div className="text-2xl mb-2">💧</div>
                <h3 className="font-semibold text-water">Water Type</h3>
                <p className="text-sm text-muted-foreground">Strong vs Fire</p>
              </div>
              <div className="p-4 bg-plant/10 rounded-lg border border-plant/30">
                <div className="text-2xl mb-2">🌿</div>
                <h3 className="font-semibold text-plant">Plant Type</h3>
                <p className="text-sm text-muted-foreground">Strong vs Water</p>
              </div>
            </div>

            <Button 
              onClick={onStartBattle}
              size="lg"
              variant="gaming"
              className="w-full h-16 text-xl font-bold"
            >
              Start Battle
            </Button>
          </div>

          <div className="text-sm text-muted-foreground space-y-2">
            <p>Use strategy to defeat your opponents!</p>
            <p>Heal your monsters, switch between them, and choose the right attacks.</p>
            <p className="text-xs mt-4 p-2 bg-muted/20 rounded">
              📁 <strong>Asset Setup:</strong> Visit <a href="/assets/extract.html" target="_blank" className="text-primary hover:underline">/assets/extract.html</a> to extract your audio and image files!
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}