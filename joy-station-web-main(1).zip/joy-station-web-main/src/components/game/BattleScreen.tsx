import { useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { GameState } from '@/types/game';
import { ABILITIES_DATA, getRandomAbilities, calculateDamage } from '@/data/gameData';
import { useAudio } from '@/hooks/useAudio';
import sparchuImg from '@/assets/monsters/sparchu.png';
import finstaImg from '@/assets/monsters/finsta.png';
import cleafImg from '@/assets/monsters/cleaf.png';

interface BattleScreenProps {
  gameState: GameState;
  onSelectAction: (action: 'attack' | 'heal' | 'switch' | 'escape') => void;
  onSelectAttack: (attack: string) => void;
  onSwitchMonster: (monster: any) => void;
  onEndTurn: () => void;
}

const monsterImages: Record<string, string> = {
  'Sparchu': sparchuImg,
  'Finsta': finstaImg,
  'Cleaf': cleafImg,
};

export function BattleScreen({ gameState, onSelectAction, onSelectAttack, onSwitchMonster, onEndTurn }: BattleScreenProps) {
  const { currentMonster, opponent, isPlayerTurn, selectedAction, animating } = gameState;
  const { playSound } = useAudio();

  // Auto-handle opponent turn
  useEffect(() => {
    if (!isPlayerTurn && !animating && opponent.health > 0 && currentMonster.health > 0) {
      const timer = setTimeout(() => {
        // Opponent attacks with random ability
        const opponentAbilities = getRandomAbilities(4);
        const randomAttack = opponentAbilities[Math.floor(Math.random() * opponentAbilities.length)];
        const ability = ABILITIES_DATA[randomAttack];
        const damage = calculateDamage(ability.element, currentMonster.element, ability.damage);
        
        // Need to trigger damage through parent component
        // For now, just end turn
        onEndTurn();
      }, 2000);

      return () => clearTimeout(timer);
    }
  }, [isPlayerTurn, animating, opponent.health, currentMonster, onEndTurn]);

  const getElementColor = (element: string) => {
    switch (element) {
      case 'fire': return 'text-fire';
      case 'water': return 'text-water';
      case 'plant': return 'text-plant';
      default: return 'text-normal';
    }
  };

  const getHealthPercent = (health: number, maxHealth: number) => {
    return (health / maxHealth) * 100;
  };

  const availableMonsters = gameState.playerMonsters.filter(
    monster => monster.name !== currentMonster.name && monster.health > 0
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted p-4">
      <div className="max-w-6xl mx-auto">
        {/* Battle Arena */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Opponent Monster */}
          <Card className="p-6 bg-card/50 backdrop-blur-sm border-2 animate-battle-enter">
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-2">{opponent.name}</h3>
              <p className={`text-lg mb-4 ${getElementColor(opponent.element)}`}>
                {opponent.element.toUpperCase()}
              </p>
              <div className="w-48 h-48 mx-auto mb-4 bg-muted/30 rounded-lg flex items-center justify-center animate-float">
                <img 
                  src={monsterImages[opponent.name] || sparchuImg} 
                  alt={opponent.name}
                  className="w-32 h-32 object-contain"
                />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>HP</span>
                  <span>{opponent.health}/{opponent.maxHealth}</span>
                </div>
                <Progress 
                  value={getHealthPercent(opponent.health, opponent.maxHealth)}
                  className="h-3"
                />
              </div>
            </div>
          </Card>

          {/* Player Monster */}
          <Card className="p-6 bg-card/50 backdrop-blur-sm border-2 animate-battle-enter">
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-2">{currentMonster.name}</h3>
              <p className={`text-lg mb-4 ${getElementColor(currentMonster.element)}`}>
                {currentMonster.element.toUpperCase()}
              </p>
              <div className="w-48 h-48 mx-auto mb-4 bg-muted/30 rounded-lg flex items-center justify-center animate-float">
                <img 
                  src={monsterImages[currentMonster.name] || sparchuImg} 
                  alt={currentMonster.name}
                  className="w-32 h-32 object-contain"
                />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>HP</span>
                  <span>{currentMonster.health}/{currentMonster.maxHealth}</span>
                </div>
                <Progress 
                  value={getHealthPercent(currentMonster.health, currentMonster.maxHealth)}
                  className="h-3"
                />
              </div>
            </div>
          </Card>
        </div>

        {/* Battle UI */}
        {isPlayerTurn && !animating && (
          <Card className="p-6 bg-card border-2">
            {!selectedAction && (
              <div>
                <h3 className="text-xl font-bold mb-4 text-center">Choose your action</h3>
                <div className="grid grid-cols-2 gap-4">
                  <Button 
                    onClick={() => {
                      onSelectAction('attack');
                      playSound('attack');
                    }}
                    variant="default"
                    className="h-16 text-lg font-semibold"
                  >
                    Attack
                  </Button>
                  <Button 
                    onClick={() => {
                      onSelectAction('heal');
                      playSound('heal');
                    }}
                    variant="secondary"
                    className="h-16 text-lg font-semibold"
                  >
                    Heal
                  </Button>
                  <Button 
                    onClick={() => onSelectAction('switch')}
                    variant="outline"
                    className="h-16 text-lg font-semibold"
                    disabled={availableMonsters.length === 0}
                  >
                    Switch
                  </Button>
                  <Button 
                    onClick={() => onSelectAction('escape')}
                    variant="destructive"
                    className="h-16 text-lg font-semibold"
                  >
                    Escape
                  </Button>
                </div>
              </div>
            )}

            {selectedAction === 'attack' && (
              <div>
                <h3 className="text-xl font-bold mb-4 text-center">Choose an attack</h3>
                <div className="grid grid-cols-2 gap-4">
                  {currentMonster.abilities.map((ability) => {
                    const abilityData = ABILITIES_DATA[ability];
                    return (
                      <Button
                        key={ability}
                        onClick={() => {
                          onSelectAttack(ability);
                          const abilityData = ABILITIES_DATA[ability];
                          playSound(abilityData.animation);
                        }}
                        variant="outline"
                        className="h-16 flex flex-col items-center justify-center"
                      >
                        <span className="font-semibold">{ability.toUpperCase()}</span>
                        <span className={`text-sm ${getElementColor(abilityData.element)}`}>
                          {abilityData.element} • {abilityData.damage} DMG
                        </span>
                      </Button>
                    );
                  })}
                </div>
              </div>
            )}

            {selectedAction === 'switch' && (
              <div>
                <h3 className="text-xl font-bold mb-4 text-center">Choose a monster</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {availableMonsters.map((monster) => (
                    <Button
                      key={monster.name}
                      onClick={() => onSwitchMonster(monster)}
                      variant="outline"
                      className="h-20 flex flex-col items-center justify-center"
                    >
                      <span className="font-semibold">{monster.name}</span>
                      <span className={`text-sm ${getElementColor(monster.element)}`}>
                        {monster.element} • HP: {monster.health}/{monster.maxHealth}
                      </span>
                    </Button>
                  ))}
                </div>
              </div>
            )}
          </Card>
        )}

        {!isPlayerTurn && (
          <Card className="p-6 bg-card border-2">
            <div className="text-center">
              <h3 className="text-xl font-bold animate-pulse">Opponent's turn...</h3>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}