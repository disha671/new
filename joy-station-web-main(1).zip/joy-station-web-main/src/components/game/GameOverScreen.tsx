import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface GameOverScreenProps {
  isVictory: boolean;
  onResetGame: () => void;
}

export function GameOverScreen({ isVictory, onResetGame }: GameOverScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted to-accent/20 flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full p-8 bg-card/80 backdrop-blur-sm border-2 shadow-2xl animate-battle-enter">
        <div className="text-center space-y-8">
          <div className="space-y-4">
            <div className="text-8xl mb-4">
              {isVictory ? '🏆' : '💀'}
            </div>
            <h1 className={`text-6xl font-bold ${
              isVictory 
                ? 'text-success animate-pulse-glow' 
                : 'text-destructive'
            }`}>
              {isVictory ? 'Victory!' : 'Defeat!'}
            </h1>
            <p className="text-xl text-muted-foreground">
              {isVictory 
                ? 'Congratulations! You defeated your opponent!' 
                : 'Your monster has fainted. Better luck next time!'}
            </p>
          </div>

          <div className="space-y-4">
            <Button 
              onClick={onResetGame}
              size="lg"
              variant="gaming"
              className="w-full h-16 text-xl font-bold"
            >
              Play Again
            </Button>
          </div>

          {isVictory && (
            <div className="text-sm text-muted-foreground space-y-2">
              <p>🎉 You mastered the art of monster battling!</p>
              <p>Try another battle to improve your skills even more.</p>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}