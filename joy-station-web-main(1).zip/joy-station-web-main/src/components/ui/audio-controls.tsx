import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { useAudio } from '@/hooks/useAudio';
import { Volume2, VolumeX } from 'lucide-react';

export function AudioControls() {
  const { setVolume, mute } = useAudio();
  const [volume, setVolumeState] = useState([70]);
  const [isMuted, setIsMuted] = useState(false);

  const handleVolumeChange = (newVolume: number[]) => {
    setVolumeState(newVolume);
    setVolume(newVolume[0] / 100);
  };

  const handleMute = () => {
    const newMuted = !isMuted;
    setIsMuted(newMuted);
    mute(newMuted);
  };

  return (
    <Card className="p-4 bg-card/80 backdrop-blur-sm border">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={handleMute}
          className="shrink-0"
        >
          {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </Button>
        
        <div className="flex-1 max-w-32">
          <Slider
            value={volume}
            onValueChange={handleVolumeChange}
            max={100}
            step={1}
            disabled={isMuted}
            className="w-full"
          />
        </div>
        
        <span className="text-sm text-muted-foreground min-w-[3ch]">
          {isMuted ? '🔇' : `${volume[0]}%`}
        </span>
      </div>
    </Card>
  );
}