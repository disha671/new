// Game types for Monster Battle

export type ElementType = 'fire' | 'water' | 'plant' | 'normal';

export interface MonsterData {
  element: ElementType;
  health: number;
}

export interface AbilityData {
  damage: number;
  element: ElementType;
  animation: string;
}

export interface Monster {
  name: string;
  element: ElementType;
  health: number;
  maxHealth: number;
  abilities: string[];
  image?: string;
}

export interface GameState {
  playerMonsters: Monster[];
  currentMonster: Monster;
  opponent: Monster;
  isPlayerTurn: boolean;
  gamePhase: 'menu' | 'battle' | 'victory' | 'defeat';
  selectedAction?: 'attack' | 'heal' | 'switch' | 'escape';
  selectedAttack?: string;
  animating: boolean;
}

export type GameAction = 
  | { type: 'SELECT_ACTION'; action: 'attack' | 'heal' | 'switch' | 'escape' }
  | { type: 'SELECT_ATTACK'; attack: string }
  | { type: 'SWITCH_MONSTER'; monster: Monster }
  | { type: 'APPLY_DAMAGE'; target: 'player' | 'opponent'; damage: number }
  | { type: 'HEAL_MONSTER'; amount: number }
  | { type: 'END_TURN' }
  | { type: 'START_BATTLE' }
  | { type: 'RESET_GAME' };